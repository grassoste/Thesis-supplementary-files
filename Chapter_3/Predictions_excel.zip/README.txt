=================================
=###############################=
=#			       #=
=# HOW TO READ THE PREDICTIONS #=
=#			       #=
=###############################=
=================================

In each Excel file there are two Tabs:

- Summary: Where we summarized the numbers of proteins predicted for each location

- Results: Zip file with the "Raw" results. 
  Here will find a large number of columns, the most important being:
	-'ID': Uniprot Identifier
	-'Seq': amino acidic sequence used for analysis
	-Columns ranging from 'Localization_LipoP' to 'Interpro_IM' which document the outputs from the various bioinformatic tools used to predict the final protein localizations
	-'My_Prediction': Final predictions as presented in Gabarrini et al. (1)
	(-Columns right to 'My_Predictions' available only for the ATCC33277 and W83 strains, present the Uniprot information for the respective proteins, including gene and protein names, gene locus, organism and length)


=================================
=###############################=
=#			       #=
=#          REFERENCE          #=
=#			       #=
=###############################=
=================================

If you found these predictions useful and you included them in your research, please cite:

(1) Gingimaps: Protein Localization in the Oral Pathogen Porphyromonas gingivalis
Giorgio Gabarrini, Stefano Grasso, Arie Jan van Winkelhoff, Jan Maarten van Dijl
Microbiology and Molecular Biology Reviews Jan 2020, 84 (1) e00032-19; DOI: 10.1128/MMBR.00032-19
